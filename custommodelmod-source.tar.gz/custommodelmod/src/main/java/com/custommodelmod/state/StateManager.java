package com.custommodelmod.state;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Handles all persistence for ModState — reading and writing storage.json.
 *
 * File location: .minecraft/config/custommodelmod/storage.json
 *
 * save() writes atomically via a .tmp file to protect against corruption
 * from mid-write crashes or power loss.
 */
public class StateManager {

    private static final Gson GSON = new GsonBuilder()
        .setPrettyPrinting()
        .serializeNulls()
        .create();

    private static final Path STATE_FILE     = ModFileManager.CONFIG_ROOT.resolve("storage.json");
    private static final Path STATE_FILE_TMP = ModFileManager.CONFIG_ROOT.resolve("storage.json.tmp");

    private static ModState currentState = new ModState();

    /** Returns the live in-memory ModState. Never null. */
    public static ModState getState() {
        return currentState;
    }

    /**
     * Adds a ModelEntry to the in-memory state and immediately persists to disk.
     * Called from RuntimeModelLoader after a successful upload.
     */
    public static void addEntry(ModelEntry entry) {
        currentState.addEntry(entry);
        save(currentState);
        CustomModelMod.LOGGER.info("[StateManager] Entry added and saved: {}", entry);
    }

    /**
     * Removes the entry for the given slot and saves the updated state.
     */
    public static void removeEntry(int slotIndex) {
        boolean removed = currentState.removeEntry(slotIndex);
        if (removed) {
            save(currentState);
            CustomModelMod.LOGGER.info("[StateManager] Slot {} removed and saved.", slotIndex);
        }
    }

    /**
     * Loads storage.json into currentState.
     * Safe to call when the file does not exist — returns an empty ModState.
     * Called once from CustomModelMod.onInitialize().
     */
    public static ModState load() {
        if (!Files.exists(STATE_FILE)) {
            CustomModelMod.LOGGER.info("[StateManager] No storage.json found — fresh state.");
            currentState = new ModState();
            return currentState;
        }

        try (Reader reader = Files.newBufferedReader(STATE_FILE, StandardCharsets.UTF_8)) {
            ModState loaded = GSON.fromJson(reader, ModState.class);
            if (loaded == null) {
                CustomModelMod.LOGGER.warn("[StateManager] storage.json empty/malformed — resetting.");
                currentState = new ModState();
                return currentState;
            }
            if (loaded.schemaVersion != ModState.CURRENT_SCHEMA_VERSION) {
                CustomModelMod.LOGGER.warn("[StateManager] Schema version mismatch: file={}, current={}.",
                    loaded.schemaVersion, ModState.CURRENT_SCHEMA_VERSION);
                loaded.schemaVersion = ModState.CURRENT_SCHEMA_VERSION;
            }
            currentState = loaded;
            CustomModelMod.LOGGER.info("[StateManager] Loaded {} entries from storage.json.",
                currentState.getEntries().size());
        } catch (IOException e) {
            CustomModelMod.LOGGER.error("[StateManager] Failed to read storage.json — fresh state.", e);
            currentState = new ModState();
        }
        return currentState;
    }

    /**
     * Atomically writes state to storage.json via a .tmp file.
     * Safe to call from any thread.
     */
    public static void save(ModState state) {
        try {
            ModFileManager.ensureDirectoriesExist();
        } catch (IOException e) {
            CustomModelMod.LOGGER.error("[StateManager] Cannot create config dirs for save.", e);
            return;
        }

        try (Writer writer = Files.newBufferedWriter(STATE_FILE_TMP, StandardCharsets.UTF_8)) {
            GSON.toJson(state, writer);
        } catch (IOException e) {
            CustomModelMod.LOGGER.error("[StateManager] Failed to write storage.json.tmp.", e);
            return;
        }

        try {
            Files.move(STATE_FILE_TMP, STATE_FILE,
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            try {
                Files.move(STATE_FILE_TMP, STATE_FILE, StandardCopyOption.REPLACE_EXISTING);
                CustomModelMod.LOGGER.warn("[StateManager] ATOMIC_MOVE unsupported — used regular move.");
            } catch (IOException ex) {
                CustomModelMod.LOGGER.error("[StateManager] Failed to finalize storage.json.", ex);
                return;
            }
        }

        CustomModelMod.LOGGER.info("[StateManager] storage.json saved ({} entries).",
            state.getEntries().size());
    }
}
