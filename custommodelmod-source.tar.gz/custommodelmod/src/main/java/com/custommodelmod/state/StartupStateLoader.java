package com.custommodelmod.state;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import com.custommodelmod.registry.PlaceholderItemRegistry;
import com.custommodelmod.resource.ModelAssignmentRegistry;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * Restores all previously saved custom models from storage.json on startup.
 *
 * Split into two phases to respect Minecraft's initialization lifecycle:
 *
 *   Phase 1 (restoreDataPhase)   — runs during onInitialize()
 *     Loads storage.json, re-claims pool slots, verifies files still exist.
 *     No GL or resource manager calls.
 *
 *   Phase 2 (registerClientPhase) — runs after client is fully started
 *     Pushes entries into ModelAssignmentRegistry and triggers one silent
 *     resource reload so models appear without any user action.
 */
public class StartupStateLoader {

    /**
     * Phase 1: Data restoration. Call from CustomModelMod.onInitialize().
     */
    public static void restoreDataPhase() {
        CustomModelMod.LOGGER.info("[StartupStateLoader] Phase 1: loading saved state...");

        ModState state = StateManager.load();
        if (state.isEmpty()) {
            CustomModelMod.LOGGER.info("[StartupStateLoader] No saved models — nothing to restore.");
            return;
        }

        int restored = 0;
        int removed  = 0;

        for (ModelEntry entry : new ArrayList<>(state.getEntries())) {
            Path modelFile = ModFileManager.MODELS_DIR.resolve(entry.modelFileName);

            if (!Files.exists(modelFile)) {
                CustomModelMod.LOGGER.warn(
                    "[StartupStateLoader] Model file missing for slot {} ({}), removing.",
                    entry.slotIndex, entry.modelFileName);
                StateManager.removeEntry(entry.slotIndex);
                removed++;
                continue;
            }

            boolean claimed = PlaceholderItemRegistry.forceClaimSlot(entry.slotIndex);
            if (!claimed) {
                CustomModelMod.LOGGER.error(
                    "[StartupStateLoader] Slot {} already claimed — skipping.", entry.slotIndex);
                continue;
            }
            restored++;
        }

        CustomModelMod.LOGGER.info("[StartupStateLoader] Phase 1 complete: {} restored, {} cleaned up.",
            restored, removed);
    }

    /**
     * Phase 2: Client-side visual registration.
     * Call from ClientModInit.onInitializeClient().
     * Fires once after the Minecraft client is fully ready.
     */
    public static void registerClientPhase() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            CustomModelMod.LOGGER.info("[StartupStateLoader] Phase 2: registering models...");

            ModState state = StateManager.getState();
            if (state.isEmpty()) return;

            boolean anyRegistered = false;

            for (ModelEntry entry : state.getEntries()) {
                Path modelFile = ModFileManager.MODELS_DIR.resolve(entry.modelFileName);
                if (!Files.exists(modelFile)) continue;

                ModelAssignmentRegistry.assign(entry.slotIndex, entry.modelFileName);
                anyRegistered = true;

                CustomModelMod.LOGGER.info(
                    "[StartupStateLoader] Phase 2: slot {} ('{}') registered.",
                    entry.slotIndex, entry.modelFileName);
            }

            if (anyRegistered) {
                client.reloadResources().thenRun(() ->
                    CustomModelMod.LOGGER.info("[StartupStateLoader] Phase 2: reload complete."));
            }
        });
    }
}
