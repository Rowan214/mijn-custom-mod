package com.custommodelmod.state;

/**
 * Represents one saved custom model entry persisted in storage.json.
 *
 * One ModelEntry corresponds to exactly one claimed placeholder item slot.
 * Stores everything needed to restore the assignment after a game restart.
 */
public class ModelEntry {

    /** Zero-based pool index (0 = custom_item_1 … 49 = custom_item_50). */
    public int slotIndex;

    /** Filename of the Blockbench model in the models folder (e.g. "my_sword.json"). */
    public String modelFileName;

    /** Filename of the generated recipe in the recipes folder, or null if not craftable. */
    public String recipeFileName;

    /** Full namespaced result item ID (e.g. "custommodelmod:custom_item_1"). */
    public String resultItemId;

    /** Human-readable display name shown in the management screen. */
    public String displayName;

    /** 9-element ingredient grid snapshot, or null if "Make Craftable" was unchecked. */
    public String[] ingredientIds;

    /** Required no-args constructor for Gson deserialization. */
    public ModelEntry() {}

    public ModelEntry(int slotIndex,
                      String modelFileName,
                      String recipeFileName,
                      String resultItemId,
                      String[] ingredientIds) {
        this.slotIndex      = slotIndex;
        this.modelFileName  = modelFileName;
        this.recipeFileName = recipeFileName;
        this.resultItemId   = resultItemId;
        this.displayName    = modelFileName.replace(".json", "");
        this.ingredientIds  = ingredientIds;
    }

    @Override
    public String toString() {
        return "ModelEntry{slot=" + slotIndex + ", model='" + modelFileName
            + "', item='" + resultItemId + "'}";
    }
}
