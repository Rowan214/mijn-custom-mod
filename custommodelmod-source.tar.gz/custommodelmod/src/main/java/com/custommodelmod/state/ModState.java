package com.custommodelmod.state;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Root data object serialized to/from storage.json.
 * Holds all saved ModelEntry records.
 */
public class ModState {

    public static final int CURRENT_SCHEMA_VERSION = 1;

    public int schemaVersion = CURRENT_SCHEMA_VERSION;
    public List<ModelEntry> entries = new ArrayList<>();

    public List<ModelEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public void addEntry(ModelEntry entry) {
        entries.add(entry);
    }

    public boolean removeEntry(int slotIndex) {
        return entries.removeIf(e -> e.slotIndex == slotIndex);
    }

    public ModelEntry findBySlot(int slotIndex) {
        return entries.stream()
            .filter(e -> e.slotIndex == slotIndex)
            .findFirst()
            .orElse(null);
    }

    public boolean isEmpty() {
        return entries.isEmpty();
    }

    @Override
    public String toString() {
        return "ModState{schemaVersion=" + schemaVersion + ", entries=" + entries.size() + "}";
    }
}
