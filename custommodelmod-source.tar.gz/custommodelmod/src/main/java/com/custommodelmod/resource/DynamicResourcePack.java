package com.custommodelmod.resource;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import net.minecraft.resource.*;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;

/**
 * Virtual resource pack that dynamically serves item model JSON files
 * from .minecraft/config/custommodelmod/models/ at runtime.
 *
 * Injected into every resource reload cycle by ResourcePackMixin so that
 * uploaded Blockbench models are immediately visible without restarting.
 *
 * 1.21.1 notes:
 *   - Identifier.of(namespace, path) replaces new Identifier(namespace, path)
 *   - ResourcePackInfo constructor is unchanged
 *   - pack_format 34 is correct for 1.21.1
 *
 * Singleton — access via INSTANCE.
 */
public class DynamicResourcePack implements ResourcePack {

    public static final DynamicResourcePack INSTANCE = new DynamicResourcePack();

    private static final String NAMESPACE = CustomModelMod.MOD_ID;
    private static final String PACK_ID   = NAMESPACE + "_dynamic_pack";

    private DynamicResourcePack() {}

    @Override
    public @Nullable InputSupplier<InputStream> open(ResourceType type, Identifier id) {
        if (type != ResourceType.CLIENT_RESOURCES)    return null;
        if (!id.getNamespace().equals(NAMESPACE))     return null;
        if (!id.getPath().startsWith("models/item/")) return null;

        String fileName = id.getPath().replace("models/item/", "");
        Path   diskPath = ModFileManager.MODELS_DIR.resolve(fileName);

        if (!Files.exists(diskPath)) return null;
        return () -> Files.newInputStream(diskPath);
    }

    @Override
    public void findResources(ResourceType type, String namespace,
                              String prefix, ResultConsumer consumer) {
        if (type != ResourceType.CLIENT_RESOURCES) return;
        if (!namespace.equals(NAMESPACE))          return;
        if (!prefix.equals("models"))              return;

        try {
            if (!Files.exists(ModFileManager.MODELS_DIR)) return;

            Files.list(ModFileManager.MODELS_DIR)
                .filter(p -> p.toString().endsWith(".json"))
                .forEach(path -> {
                    String fileName = path.getFileName().toString();
                    // 1.21.1: Identifier.of() replaces new Identifier()
                    Identifier id = Identifier.of(NAMESPACE, "models/item/" + fileName);
                    consumer.accept(id, () -> Files.newInputStream(path));
                    CustomModelMod.LOGGER.debug("[DynamicResourcePack] Exposed: {}", id);
                });
        } catch (IOException e) {
            CustomModelMod.LOGGER.error("[DynamicResourcePack] Error scanning models dir.", e);
        }
    }

    @Override
    public Set<String> getNamespaces(ResourceType type) {
        if (type == ResourceType.CLIENT_RESOURCES) return Set.of(NAMESPACE);
        return Set.of();
    }

    @Override
    public @Nullable InputSupplier<InputStream> openRoot(String... segments) {
        if (segments.length == 1 && segments[0].equals("pack.mcmeta")) {
            // pack_format 34 = Minecraft 1.21.1
            String meta = "{\"pack\":{\"pack_format\":34,"
                        + "\"description\":\"Custom Model Mod Dynamic Pack\"}}";
            byte[] bytes = meta.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            return () -> new java.io.ByteArrayInputStream(bytes);
        }
        return null;
    }

    @Override
    public @Nullable <T> T parseMetadata(ResourceMetadataReader<T> metaReader) {
        return null;
    }

    @Override
    public ResourcePackInfo getInfo() {
        return new ResourcePackInfo(
            PACK_ID,
            Text.literal("Custom Model Mod Dynamic Pack"),
            ResourcePackSource.BUILTIN,
            Optional.empty()
        );
    }

    @Override
    public void close() {}
}
