package com.custommodelmod.resource;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import com.custommodelmod.registry.PlaceholderItemRegistry;
import com.custommodelmod.state.ModelEntry;
import com.custommodelmod.state.StateManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * Orchestrates the full pipeline for registering a new uploaded model at runtime.
 *
 * Updated for Minecraft 1.21.1:
 *   - Identifier.of(namespace, path) replaces new Identifier(namespace, path)
 *   - mouseScrolled 4-parameter signature handled in GUI classes
 *   - All other APIs (reloadResources, Registries, ItemStack) are unchanged
 *
 * Steps (from GUI Save button):
 *   1. Ensure directories exist
 *   2. Copy uploaded .json to models folder
 *   3. Claim next free placeholder item slot
 *   4. Register in ModelAssignmentRegistry (writes item model definition JSON)
 *   5. Optionally generate crafting recipe JSON
 *   6. Persist state to storage.json via StateManager
 *   7. Trigger silent client resource reload + integrated server recipe reload
 *   8. Give the new item to the player for immediate testing
 *
 * All disk I/O runs on a background thread. MC reload is marshalled back
 * to the main thread via client.execute().
 */
public class RuntimeModelLoader {

    /**
     * Main entry point. Called from CustomModelScreen.onSaveClicked().
     *
     * @param selectedModelPath absolute path of the user-chosen .json file
     * @param ingredientGrid    9-element ingredient array, or null if not craftable
     */
    public static void registerModelAndReload(String selectedModelPath,
                                               String[] ingredientGrid) {
        CompletableFuture.runAsync(() -> {
            try {
                performRegistration(selectedModelPath, ingredientGrid);
            } catch (Exception e) {
                CustomModelMod.LOGGER.error("[RuntimeModelLoader] Registration failed.", e);
                MinecraftClient client = MinecraftClient.getInstance();
                client.execute(() -> {
                    if (client.player != null) {
                        client.player.sendMessage(
                            Text.literal("§cModel registration failed: " + e.getMessage()), false);
                    }
                });
            }
        });
    }

    private static void performRegistration(String selectedModelPath,
                                             String[] ingredientGrid) throws IOException {
        MinecraftClient client = MinecraftClient.getInstance();

        // 1. Ensure directories exist
        ModFileManager.ensureDirectoriesExist();

        // 2. Copy model JSON into mod folder
        Path copiedModel     = ModFileManager.copyModelToModFolder(selectedModelPath);
        String modelFileName = copiedModel.getFileName().toString();
        String modelName     = modelFileName.replace(".json", "");

        // 3. Claim pool slot
        Optional<Integer> slotOpt = PlaceholderItemRegistry.claimNextSlot();
        if (slotOpt.isEmpty()) {
            throw new IllegalStateException("All 50 placeholder slots are occupied.");
        }
        int slotIndex = slotOpt.get();

        // 1.21.1: use Identifier.of() instead of new Identifier()
        Item resultItem = PlaceholderItemRegistry.getItem(slotIndex);
        Identifier resultIdentifier = Registries.ITEM.getId(resultItem);
        String resultId = resultIdentifier.toString();

        // 4. Register model → item mapping (writes item model definition JSON)
        ModelAssignmentRegistry.assign(slotIndex, modelFileName);

        // 5. Optionally generate crafting recipe
        String recipeFileName = null;
        if (ingredientGrid != null) {
            ModFileManager.generateRecipeJson(modelName, ingredientGrid, resultId);
            recipeFileName = modelName + ".json";
        }

        // 6. Persist state (writes storage.json atomically)
        ModelEntry entry = new ModelEntry(slotIndex, modelFileName, recipeFileName,
                                          resultId, ingredientGrid);
        StateManager.addEntry(entry);

        CustomModelMod.LOGGER.info("[RuntimeModelLoader] '{}' registered as '{}'.",
            modelName, resultId);

        // 7 & 8. Trigger reloads and give item on the main thread
        client.execute(() -> triggerSilentReload(client, modelName, slotIndex));
    }

    /**
     * Triggers a silent resource reload (equivalent to F3+T) then reloads the
     * integrated server's recipe manager so new recipes take effect immediately.
     */
    private static void triggerSilentReload(MinecraftClient client,
                                             String modelName, int slotIndex) {
        CustomModelMod.LOGGER.info("[RuntimeModelLoader] Starting silent resource reload...");

        client.reloadResources()
            .thenRunAsync(() -> {
                // Reload integrated server data packs to pick up new recipes
                if (client.getServer() != null) {
                    Collection<String> packs =
                        client.getServer().getDataPackManager().getEnabledNames();
                    client.getServer().reloadResources(packs).exceptionally(e -> {
                        CustomModelMod.LOGGER.error(
                            "[RuntimeModelLoader] Server data reload failed.", e);
                        return null;
                    });
                }

                // Give new item to player for immediate inspection
                giveItemToPlayer(client, slotIndex);

                // Notify player
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(
                        "§aModel §e'" + modelName + "' §aregistered as §e"
                        + CustomModelMod.MOD_ID + ":custom_item_" + (slotIndex + 1)
                        + " §a— ready!"), false);
                }
            }, client);
    }

    private static void giveItemToPlayer(MinecraftClient client, int slotIndex) {
        if (client.player == null) return;
        Item      item  = PlaceholderItemRegistry.getItem(slotIndex);
        ItemStack stack = new ItemStack(item);
        boolean   added = client.player.getInventory().insertStack(stack);
        if (!added) {
            client.player.dropItem(stack, false);
        }
    }
}
