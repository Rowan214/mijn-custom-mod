package com.custommodelmod.resource;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Tracks which placeholder item slot has been assigned to which uploaded model filename.
 *
 * Maps: slot index (0–49) → model filename (e.g. "my_sword.json")
 *
 * In-memory only. Rebuilt each game session by StartupStateLoader.
 *
 * 1.21.1: No API changes in this class. Identifier.of() is used in
 * DynamicResourcePack; here we only deal with plain strings and file I/O.
 */
public class ModelAssignmentRegistry {

    private static final Map<Integer, String> slotToFileName = new HashMap<>();

    /**
     * Assigns a model filename to a pool slot and writes the item model
     * definition JSON that Minecraft needs to resolve the model via
     * DynamicResourcePack.
     */
    public static void assign(int slotIndex, String fileName) {
        slotToFileName.put(slotIndex, fileName);
        CustomModelMod.LOGGER.info("[ModelAssignmentRegistry] Slot {} → '{}'.", slotIndex, fileName);
        writeItemModelDefinition(slotIndex, fileName);
    }

    /**
     * Removes the in-memory assignment for a slot.
     * Does NOT delete files — file deletion is the caller's responsibility.
     */
    public static void unassign(int slotIndex) {
        String removed = slotToFileName.remove(slotIndex);
        if (removed != null) {
            CustomModelMod.LOGGER.info(
                "[ModelAssignmentRegistry] Slot {} unassigned (was '{}').", slotIndex, removed);
        } else {
            CustomModelMod.LOGGER.warn(
                "[ModelAssignmentRegistry] unassign for slot {} — no entry found.", slotIndex);
        }
    }

    public static String getFileName(int slotIndex) {
        return slotToFileName.get(slotIndex);
    }

    public static Map<Integer, String> getAllAssignments() {
        return Collections.unmodifiableMap(slotToFileName);
    }

    /**
     * Writes a minimal item model definition JSON for the placeholder item.
     *
     * Written to: <modelsDir>/custom_item_N.json
     * Served by DynamicResourcePack as:
     *   assets/custommodelmod/models/item/custom_item_N.json
     */
    private static void writeItemModelDefinition(int slotIndex, String sourceFileName) {
        String itemName           = "custom_item_" + (slotIndex + 1);
        String definitionFileName = itemName + ".json";
        String modelRef           = CustomModelMod.MOD_ID + ":"
                                    + sourceFileName.replace(".json", "");

        String json = String.format("""
            {
              "parent": "item/generated",
              "textures": {
                "layer0": "custommodelmod:item/missing"
              },
              "__source_model": "%s",
              "__slot_index": %d
            }
            """, modelRef, slotIndex);

        java.nio.file.Path dest = ModFileManager.MODELS_DIR.resolve(definitionFileName);
        try {
            Files.writeString(dest, json, StandardCharsets.UTF_8);
            CustomModelMod.LOGGER.info(
                "[ModelAssignmentRegistry] Item model definition written: {}", dest);
        } catch (IOException e) {
            CustomModelMod.LOGGER.error(
                "[ModelAssignmentRegistry] Failed to write item model definition.", e);
        }
    }
}
