package com.custommodelmod.mixin;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.resource.DynamicResourcePack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Injects DynamicResourcePack into Minecraft's resource reload pipeline.
 *
 * Every time resources are reloaded (F3+T, startup, or programmatic),
 * this Mixin appends our virtual pack to the active pack list so that
 * uploaded model JSONs are included in the reload.
 *
 * Target: MinecraftClient.reloadResources(List<ResourcePack>)
 * The private overload that receives the fully resolved pack list.
 */
@Mixin(MinecraftClient.class)
public class ResourcePackMixin {

    @Inject(
        method = "reloadResources(Ljava/util/List;)Ljava/util/concurrent/CompletableFuture;",
        at = @At("HEAD"),
        cancellable = true
    )
    private void injectDynamicPack(List<ResourcePack> packs,
                                    CallbackInfoReturnable<CompletableFuture<Void>> cir) {

        // Idempotency guard: do not inject twice if the pack is already present
        boolean alreadyPresent = packs.stream()
            .anyMatch(p -> p.getInfo().id().equals(
                DynamicResourcePack.INSTANCE.getInfo().id()));
        if (alreadyPresent) return;

        // Build a mutable copy and append our pack at the end (highest priority)
        List<ResourcePack> augmented = new ArrayList<>(packs);
        augmented.add(DynamicResourcePack.INSTANCE);

        CustomModelMod.LOGGER.info(
            "[ResourcePackMixin] Injected DynamicResourcePack. Total packs: {}",
            augmented.size());

        // Re-invoke the same method with the augmented list via reflection
        MinecraftClient client = (MinecraftClient) (Object) this;
        cir.setReturnValue(invokeReloadResources(client, augmented));
        cir.cancel();
    }

    private static CompletableFuture<Void> invokeReloadResources(
            MinecraftClient client, List<ResourcePack> packs) {
        try {
            java.lang.reflect.Method m = MinecraftClient.class
                .getDeclaredMethod("reloadResources", List.class);
            m.setAccessible(true);
            @SuppressWarnings("unchecked")
            CompletableFuture<Void> future = (CompletableFuture<Void>) m.invoke(client, packs);
            return future;
        } catch (Exception e) {
            CustomModelMod.LOGGER.error(
                "[ResourcePackMixin] Reflection invocation of reloadResources failed.", e);
            return CompletableFuture.completedFuture(null);
        }
    }
}
