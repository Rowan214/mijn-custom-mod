package com.custommodelmod;

import com.custommodelmod.io.ModFileManager;
import com.custommodelmod.registry.PlaceholderItemRegistry;
import com.custommodelmod.state.StartupStateLoader;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Main mod entrypoint — Minecraft 1.21.1 / Fabric 0.16.x.
 *
 * Initialization order:
 *   1. Register 50 placeholder items (before registry freeze)
 *   2. Add them to the Ingredients creative group (visible in dev)
 *   3. Ensure config directories exist
 *   4. Phase 1 restore: read storage.json, re-claim pool slots
 *
 * Client-side Phase 2 (visual resource registration) runs in ClientModInit
 * after the Minecraft client is fully ready.
 */
public class CustomModelMod implements ModInitializer {

    public static final String MOD_ID = "custommodelmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[CustomModelMod] Initializing (1.21.1)...");

        // 1. Register placeholder item pool
        PlaceholderItemRegistry.registerAll();

        // 2. Expose placeholder items in creative inventory (Ingredients tab)
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries ->
            PlaceholderItemRegistry.getAllItems().forEach(entries::add));

        // 3. Ensure mod config directories exist
        try {
            ModFileManager.ensureDirectoriesExist();
        } catch (IOException e) {
            LOGGER.error("[CustomModelMod] Could not create config directories.", e);
        }

        // 4. Phase 1 restore: load storage.json and re-claim saved pool slots
        StartupStateLoader.restoreDataPhase();

        LOGGER.info("[CustomModelMod] Initialization complete.");
    }
}
