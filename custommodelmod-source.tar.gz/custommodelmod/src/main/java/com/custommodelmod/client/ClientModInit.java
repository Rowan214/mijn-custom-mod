package com.custommodelmod.client;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.client.gui.CustomModelScreen;
import com.custommodelmod.state.StartupStateLoader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Client-side mod initializer for Minecraft 1.21.1.
 *
 * Registers:
 *   - Keybinding: M key → opens CustomModelScreen
 *   - Phase 2 of startup restore (visual model registration after client ready)
 *
 * No API changes between 1.20.4 and 1.21.1 in this class.
 */
@Environment(EnvType.CLIENT)
public class ClientModInit implements ClientModInitializer {

    private static KeyBinding openScreenKey;

    @Override
    public void onInitializeClient() {
        CustomModelMod.LOGGER.info("[ClientModInit] Initializing client...");

        openScreenKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.custommodelmod.open_screen",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_M,
            "category.custommodelmod.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openScreenKey.wasPressed()) {
                if (client.currentScreen == null) {
                    MinecraftClient.getInstance().setScreen(new CustomModelScreen());
                }
            }
        });

        // Phase 2: register saved models once the client is fully started
        StartupStateLoader.registerClientPhase();

        CustomModelMod.LOGGER.info("[ClientModInit] Client initialization complete.");
    }
}
