package com.custommodelmod.client.gui;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import com.custommodelmod.registry.PlaceholderItemRegistry;
import com.custommodelmod.resource.ModelAssignmentRegistry;
import com.custommodelmod.state.ModelEntry;
import com.custommodelmod.state.ModState;
import com.custommodelmod.state.StateManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Management screen for all registered custom models — updated for 1.21.1.
 *
 * API changes vs 1.20.4:
 *   - renderBackground() now takes (context, mouseX, mouseY, delta)
 *   - mouseScrolled() now has 4 parameters (added horizontalAmount)
 *   - Identifier.of() used where applicable
 *
 * Each list row: [icon]  display name  |  item id  |  [Rename]  [Delete]
 * Rename: inline TextFieldWidget — Enter/Save commits, Escape/Cancel discards.
 * Delete: removes files, unregisters, frees slot, updates storage.json, reloads.
 */
public class ModelManagementScreen extends Screen {

    // ── Layout ────────────────────────────────────────────────────────────────
    private static final int ROW_HEIGHT   = 28;
    private static final int VISIBLE_ROWS = 8;
    private static final int LIST_HEIGHT  = ROW_HEIGHT * VISIBLE_ROWS;
    private static final int LIST_WIDTH   = 460;
    private static final int BTN_WIDTH    = 52;
    private static final int BTN_GAP      = 4;

    // ── State ─────────────────────────────────────────────────────────────────
    private List<ModelEntry> entries    = new ArrayList<>();
    private int  scrollOffset           = 0;
    private int  renamingSlot           = -1;
    private TextFieldWidget renameField = null;

    private final Screen parent;

    // ── Cached layout anchors ─────────────────────────────────────────────────
    private int listX, listY, listRight;

    public ModelManagementScreen(Screen parent) {
        super(Text.literal("Manage Saved Models"));
        this.parent = parent;
    }

    // ── Screen lifecycle ──────────────────────────────────────────────────────

    @Override
    protected void init() {
        super.init();
        listX     = (this.width  - LIST_WIDTH) / 2;
        listY     = (this.height - LIST_HEIGHT) / 2 - 20;
        listRight = listX + LIST_WIDTH;

        refreshEntries();
        rebuildRowButtons();

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"), btn -> this.close())
            .dimensions(this.width / 2 - 50, listY + LIST_HEIGHT + 16, 100, 20)
            .build());
    }

    private void refreshEntries() {
        entries      = new ArrayList<>(StateManager.getState().getEntries());
        scrollOffset = Math.min(scrollOffset, Math.max(0, entries.size() - VISIBLE_ROWS));
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    // ── Rendering ─────────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // 1.21.1: renderBackground takes 4 arguments
        this.renderBackground(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer,
            Text.literal("Manage Saved Models"),
            this.width / 2, listY - 22, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
            Text.literal(entries.size() + " / 50 slots used"),
            this.width / 2, listY - 10, 0x888888);

        // Panel border
        context.fill(listX - 2, listY - 2, listRight + 2, listY + LIST_HEIGHT + 2, 0xFF222222);
        context.fill(listX - 1, listY - 1, listRight + 1, listY + LIST_HEIGHT + 1, 0xFF444444);

        if (entries.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("No custom models saved yet."),
                this.width / 2, listY + LIST_HEIGHT / 2 - 4, 0x888888);
        } else {
            renderEntryRows(context, mouseX, mouseY);
        }

        if (entries.size() > VISIBLE_ROWS) {
            int total   = (int) Math.ceil((double) entries.size() / VISIBLE_ROWS);
            int current = scrollOffset / VISIBLE_ROWS + 1;
            context.drawTextWithShadow(this.textRenderer,
                Text.literal("▲▼ Page " + current + "/" + total),
                listRight - 70, listY + LIST_HEIGHT + 4, 0x666666);
        }

        super.render(context, mouseX, mouseY, delta);

        if (renamingSlot >= 0 && renameField != null) {
            renameField.render(context, mouseX, mouseY, delta);
        }
    }

    private void renderEntryRows(DrawContext context, int mouseX, int mouseY) {
        int start = scrollOffset;
        int end   = Math.min(start + VISIBLE_ROWS, entries.size());

        for (int i = start; i < end; i++) {
            ModelEntry entry = entries.get(i);
            int rowY         = listY + (i - start) * ROW_HEIGHT;

            context.fill(listX, rowY, listRight, rowY + ROW_HEIGHT - 1,
                i % 2 == 0 ? 0xFF2A2A2A : 0xFF303030);

            if (entry.slotIndex >= 0 && entry.slotIndex < PlaceholderItemRegistry.POOL_SIZE) {
                context.drawItem(
                    new ItemStack(PlaceholderItemRegistry.getItem(entry.slotIndex)),
                    listX + 6, rowY + 6);
            }

            if (renamingSlot != entry.slotIndex) {
                String name = entry.displayName != null ? entry.displayName : entry.modelFileName;
                if (name.length() > 22) name = name.substring(0, 20) + "…";
                context.drawTextWithShadow(this.textRenderer,
                    Text.literal(name), listX + 28, rowY + 5, 0xFFFFFF);
                context.drawTextWithShadow(this.textRenderer,
                    Text.literal(entry.resultItemId != null ? entry.resultItemId : "—"),
                    listX + 28, rowY + 15, 0x888888);
            }
        }
    }

    // ── Dynamic button rebuilding ─────────────────────────────────────────────

    private void rebuildRowButtons() {
        this.clearChildren();

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("← Back"), btn -> this.close())
            .dimensions(this.width / 2 - 50, listY + LIST_HEIGHT + 16, 100, 20)
            .build());

        int start = scrollOffset;
        int end   = Math.min(start + VISIBLE_ROWS, entries.size());

        for (int i = start; i < end; i++) {
            ModelEntry entry = entries.get(i);
            int rowY         = listY + (i - start) * ROW_HEIGHT;
            int btnY         = rowY + 5;
            int deleteX      = listRight - BTN_WIDTH - 4;
            int renameX      = deleteX - BTN_WIDTH - BTN_GAP;
            final int slot   = entry.slotIndex;

            if (renamingSlot == slot) {
                renameField = new TextFieldWidget(
                    this.textRenderer,
                    listX + 28, rowY + 4,
                    renameX - (listX + 32), ROW_HEIGHT - 8,
                    Text.literal("Display name"));
                renameField.setMaxLength(48);
                renameField.setText(entry.displayName != null
                    ? entry.displayName
                    : entry.modelFileName.replace(".json", ""));
                renameField.setFocused(true);
                this.addDrawableChild(renameField);

                this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("Save"), btn -> commitRename(slot))
                    .dimensions(renameX, btnY, BTN_WIDTH, ROW_HEIGHT - 10)
                    .build());
                this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("Cancel"), btn -> cancelRename())
                    .dimensions(deleteX, btnY, BTN_WIDTH, ROW_HEIGHT - 10)
                    .build());
            } else {
                this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("Rename"), btn -> startRename(slot))
                    .dimensions(renameX, btnY, BTN_WIDTH, ROW_HEIGHT - 10)
                    .build());
                this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("§cDelete"), btn -> deleteEntry(slot))
                    .dimensions(deleteX, btnY, BTN_WIDTH, ROW_HEIGHT - 10)
                    .build());
            }
        }
    }

    // ── Rename ────────────────────────────────────────────────────────────────

    private void startRename(int slotIndex) {
        renamingSlot = slotIndex;
        rebuildRowButtons();
    }

    private void commitRename(int slotIndex) {
        if (renameField == null) return;
        String newName = renameField.getText().trim();
        if (newName.isEmpty()) { cancelRename(); return; }

        ModState   state = StateManager.getState();
        ModelEntry entry = state.findBySlot(slotIndex);
        if (entry != null) {
            entry.displayName = newName;
            StateManager.save(state);
        }
        renamingSlot = -1;
        renameField  = null;
        refreshEntries();
        rebuildRowButtons();
    }

    private void cancelRename() {
        renamingSlot = -1;
        renameField  = null;
        rebuildRowButtons();
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    private void deleteEntry(int slotIndex) {
        ModelEntry entry = StateManager.getState().findBySlot(slotIndex);
        if (entry == null) return;

        StateManager.removeEntry(slotIndex);
        ModelAssignmentRegistry.unassign(slotIndex);
        PlaceholderItemRegistry.releaseSlot(slotIndex);

        deleteFileIfExists(ModFileManager.MODELS_DIR.resolve(entry.modelFileName), "model");
        deleteFileIfExists(
            ModFileManager.MODELS_DIR.resolve("custom_item_" + (slotIndex + 1) + ".json"),
            "item model definition");
        if (entry.recipeFileName != null) {
            deleteFileIfExists(
                ModFileManager.RECIPES_DIR.resolve(entry.recipeFileName), "recipe");
        }

        if (renamingSlot == slotIndex) { renamingSlot = -1; renameField = null; }

        refreshEntries();
        rebuildRowButtons();
        triggerDeleteReload(entry.displayName != null ? entry.displayName : entry.modelFileName);
    }

    private void triggerDeleteReload(String deletedName) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.reloadResources().thenRunAsync(() -> {
            if (client.getServer() != null) {
                java.util.Collection<String> packs =
                    client.getServer().getDataPackManager().getEnabledNames();
                client.getServer().reloadResources(packs).exceptionally(e -> {
                    CustomModelMod.LOGGER.error(
                        "[ModelManagementScreen] Server reload after delete failed.", e);
                    return null;
                });
            }
            if (client.player != null) {
                client.player.sendMessage(Text.literal(
                    "§cModel §e'" + deletedName + "' §cdeleted — slot freed."), false);
            }
        }, client);
    }

    // ── Scroll ────────────────────────────────────────────────────────────────

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY,
                                  double horizontalAmount, double verticalAmount) {
        // 1.21.1: 4-parameter version of mouseScrolled
        boolean overList = mouseX >= listX && mouseX <= listRight
                        && mouseY >= listY && mouseY <= listY + LIST_HEIGHT;
        if (overList && entries.size() > VISIBLE_ROWS) {
            int maxOffset = entries.size() - VISIBLE_ROWS;
            int newOffset = (int) Math.max(0, Math.min(maxOffset, scrollOffset - verticalAmount));
            if (newOffset != scrollOffset) {
                scrollOffset = newOffset;
                rebuildRowButtons();
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    // ── Keyboard ──────────────────────────────────────────────────────────────

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (renamingSlot >= 0 && renameField != null && renameField.isFocused()) {
            if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER
             || keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER) {
                commitRename(renamingSlot); return true;
            }
            if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
                cancelRename(); return true;
            }
            return renameField.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (renamingSlot >= 0 && renameField != null && renameField.isFocused()) {
            return renameField.charTyped(chr, modifiers);
        }
        return super.charTyped(chr, modifiers);
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    private static void deleteFileIfExists(Path path, String type) {
        try {
            boolean deleted = Files.deleteIfExists(path);
            if (deleted) CustomModelMod.LOGGER.info(
                "[ModelManagementScreen] Deleted {} file: {}", type, path);
        } catch (IOException e) {
            CustomModelMod.LOGGER.error(
                "[ModelManagementScreen] Failed to delete {} file: {}", type, path, e);
        }
    }

    @Override
    public boolean shouldPause() { return false; }
}
