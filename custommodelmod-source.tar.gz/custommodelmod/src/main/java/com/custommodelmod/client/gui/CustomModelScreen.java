package com.custommodelmod.client.gui;

import com.custommodelmod.CustomModelMod;
import com.custommodelmod.io.ModFileManager;
import com.custommodelmod.resource.RuntimeModelLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Main GUI screen for the Custom Model Mod — updated for Minecraft 1.21.1.
 *
 * API changes vs 1.20.4:
 *   - CheckboxWidget now uses a builder pattern (.builder().pos().build())
 *   - Identifier constructor replaced by Identifier.of(namespace, path)
 *   - Java target is now 21
 *
 * Opened by pressing M in-game (registered in ClientModInit).
 *
 * Left-click browser item  → selects it (blue highlight)
 * Left-click grid slot     → assigns selected item to that slot
 * Right-click grid slot    → clears that slot
 * Scroll over browser      → scrolls the item list
 */
public class CustomModelScreen extends Screen {

    // ── Layout constants ──────────────────────────────────────────────────────
    private static final int SLOT_SIZE    = 18;
    private static final int BROWSER_COLS = 5;
    private static final int BROWSER_ROWS = 4;
    private static final int BROWSER_VIS  = BROWSER_COLS * BROWSER_ROWS;

    // ── Crafting grid: 9 slots indexed [0..8], null = empty ──────────────────
    private final ItemStack[] craftingGrid = new ItemStack[9];

    // ── Item browser state ────────────────────────────────────────────────────
    private List<Item> allItems            = new ArrayList<>();
    private List<Item> filteredItems       = new ArrayList<>();
    private int        browserScrollOffset = 0;
    private Item       selectedBrowserItem = null;

    // ── File selection ────────────────────────────────────────────────────────
    private String selectedModelPath = null;
    private String selectedFileLabel = "No file selected.";

    // ── Widgets ───────────────────────────────────────────────────────────────
    private ButtonWidget    addModelButton;
    private CheckboxWidget  makeCraftableCheckbox;
    private TextFieldWidget searchBar;
    private ButtonWidget    saveButton;
    private ButtonWidget    cancelButton;
    private ButtonWidget    manageButton;

    // ── Cached layout positions ───────────────────────────────────────────────
    private int gridOriginX, gridOriginY;
    private int browserOriginX, browserOriginY;

    public CustomModelScreen() {
        super(Text.literal("Custom Model Loader"));
    }

    // ── Screen lifecycle ──────────────────────────────────────────────────────

    @Override
    protected void init() {
        super.init();

        int cx = this.width / 2;
        int cy = this.height / 2;

        // File picker button
        addModelButton = ButtonWidget.builder(
                Text.literal("Add Custom Model (.json)"),
                btn -> onAddModelClicked())
            .dimensions(cx - 160, cy - 100, 160, 20)
            .build();

        // ── 1.21.1: CheckboxWidget now uses a builder ─────────────────────────
        makeCraftableCheckbox = CheckboxWidget.builder(
                Text.literal("Make Craftable"),
                this.textRenderer)
            .pos(cx - 160, cy - 72)
            .checked(false)
            .build();

        // Crafting grid and browser origins
        gridOriginX    = cx - 140;
        gridOriginY    = cy - 40;
        browserOriginX = gridOriginX + 3 * SLOT_SIZE + 60;
        browserOriginY = cy - 40;

        // Search bar above the item browser
        searchBar = new TextFieldWidget(
            this.textRenderer,
            browserOriginX, browserOriginY - 24,
            BROWSER_COLS * SLOT_SIZE + 4, 18,
            Text.literal("Search..."));
        searchBar.setMaxLength(64);
        searchBar.setPlaceholder(Text.literal("Search items..."));
        searchBar.setChangedListener(this::onSearchChanged);

        // Action buttons
        saveButton = ButtonWidget.builder(
                Text.literal("Save"), btn -> onSaveClicked())
            .dimensions(cx - 50, cy + 90, 60, 20)
            .build();

        cancelButton = ButtonWidget.builder(
                Text.literal("Cancel"), btn -> this.close())
            .dimensions(cx + 15, cy + 90, 60, 20)
            .build();

        manageButton = ButtonWidget.builder(
                Text.literal("Manage Saved Models"),
                btn -> MinecraftClient.getInstance()
                           .setScreen(new ModelManagementScreen(this)))
            .dimensions(cx - 60, cy + 116, 160, 20)
            .build();

        this.addDrawableChild(addModelButton);
        this.addDrawableChild(makeCraftableCheckbox);
        this.addDrawableChild(searchBar);
        this.addDrawableChild(saveButton);
        this.addDrawableChild(cancelButton);
        this.addDrawableChild(manageButton);

        // Populate from registry — Registries.ITEM unchanged in 1.21.1
        allItems      = new ArrayList<>(Registries.ITEM.stream().toList());
        filteredItems = new ArrayList<>(allItems);
    }

    // ── Rendering ─────────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // DrawContext API is unchanged between 1.20.4 and 1.21.1
        this.renderBackground(context, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int cy = this.height / 2;

        context.drawCenteredTextWithShadow(this.textRenderer,
            Text.literal("Custom Model Loader"), cx, cy - 120, 0xFFFFFF);

        // Truncate long paths for the label
        String label = selectedFileLabel.length() > 45
            ? "..." + selectedFileLabel.substring(selectedFileLabel.length() - 42)
            : selectedFileLabel;
        context.drawTextWithShadow(this.textRenderer,
            Text.literal(label), cx - 160 + 165, cy - 95, 0xAAAAAA);

        // Default widget rendering
        super.render(context, mouseX, mouseY, delta);

        // Crafting panel (only when checkbox is checked)
        if (makeCraftableCheckbox.isChecked()) {
            renderCraftingGrid(context, mouseX, mouseY);
            renderItemBrowser(context, mouseX, mouseY);
            renderArrow(context);
            renderBrowserTooltip(context, mouseX, mouseY);
        }
    }

    private void renderCraftingGrid(DrawContext context, int mouseX, int mouseY) {
        for (int i = 0; i < 9; i++) {
            int col   = i % 3;
            int row   = i / 3;
            int slotX = gridOriginX + col * SLOT_SIZE;
            int slotY = gridOriginY + row * SLOT_SIZE;

            boolean hovered = mouseX >= slotX && mouseX < slotX + SLOT_SIZE
                           && mouseY >= slotY && mouseY < slotY + SLOT_SIZE;

            context.fill(slotX, slotY, slotX + SLOT_SIZE - 1, slotY + SLOT_SIZE - 1,
                hovered ? 0xFF888888 : 0xFF555555);
            context.fill(slotX, slotY, slotX + SLOT_SIZE - 1, slotY + 1, 0xFF999999);
            context.fill(slotX, slotY, slotX + 1, slotY + SLOT_SIZE - 1, 0xFF999999);

            if (craftingGrid[i] != null && !craftingGrid[i].isEmpty()) {
                context.drawItem(craftingGrid[i], slotX + 1, slotY + 1);
            }
        }

        // Output slot
        int outX = gridOriginX + 3 * SLOT_SIZE + 36;
        int outY = gridOriginY + SLOT_SIZE;
        context.fill(outX, outY, outX + SLOT_SIZE - 1, outY + SLOT_SIZE - 1, 0xFF777700);
        context.fill(outX, outY, outX + SLOT_SIZE - 1, outY + 1, 0xFFAAAA00);
        context.fill(outX, outY, outX + 1, outY + SLOT_SIZE - 1, 0xFFAAAA00);
        context.drawTextWithShadow(this.textRenderer,
            Text.literal("OUT"), outX, outY + SLOT_SIZE + 2, 0xFFFFAA);
    }

    private void renderArrow(DrawContext context) {
        context.drawTextWithShadow(this.textRenderer,
            Text.literal("►"),
            gridOriginX + 3 * SLOT_SIZE + 8, gridOriginY + SLOT_SIZE + 4, 0xFFFFFF);
    }

    private void renderItemBrowser(DrawContext context, int mouseX, int mouseY) {
        int panelW = BROWSER_COLS * SLOT_SIZE + 8;
        int panelH = BROWSER_ROWS * SLOT_SIZE + 8;
        context.fill(browserOriginX - 2, browserOriginY - 2,
                     browserOriginX + panelW, browserOriginY + panelH, 0xFF333333);

        int start = browserScrollOffset * BROWSER_COLS;
        int end   = Math.min(start + BROWSER_VIS, filteredItems.size());

        for (int i = start; i < end; i++) {
            int local = i - start;
            int cellX = browserOriginX + (local % BROWSER_COLS) * SLOT_SIZE;
            int cellY = browserOriginY + (local / BROWSER_COLS) * SLOT_SIZE;

            Item    item  = filteredItems.get(i);
            boolean hover = mouseX >= cellX && mouseX < cellX + SLOT_SIZE
                         && mouseY >= cellY && mouseY < cellY + SLOT_SIZE;
            boolean sel   = item == selectedBrowserItem;

            context.fill(cellX, cellY, cellX + SLOT_SIZE - 1, cellY + SLOT_SIZE - 1,
                sel ? 0xFF2255AA : (hover ? 0xFF666666 : 0xFF444444));
            context.drawItem(new ItemStack(item), cellX + 1, cellY + 1);
        }

        int totalRows = (int) Math.ceil((double) filteredItems.size() / BROWSER_COLS);
        context.drawTextWithShadow(this.textRenderer,
            Text.literal("Row " + (browserScrollOffset + 1) + "/" + Math.max(1, totalRows)),
            browserOriginX, browserOriginY + panelH + 4, 0x888888);
    }

    private void renderBrowserTooltip(DrawContext context, int mouseX, int mouseY) {
        int start = browserScrollOffset * BROWSER_COLS;
        int end   = Math.min(start + BROWSER_VIS, filteredItems.size());

        for (int i = start; i < end; i++) {
            int local = i - start;
            int cellX = browserOriginX + (local % BROWSER_COLS) * SLOT_SIZE;
            int cellY = browserOriginY + (local / BROWSER_COLS) * SLOT_SIZE;

            if (mouseX >= cellX && mouseX < cellX + SLOT_SIZE
             && mouseY >= cellY && mouseY < cellY + SLOT_SIZE) {
                context.drawTooltip(this.textRenderer,
                    filteredItems.get(i).getName(), mouseX, mouseY);
                return;
            }
        }
    }

    // ── Input handling ────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseClicked(mouseX, mouseY, button);

        if (makeCraftableCheckbox.isChecked()) {
            if (button == 0) {
                handleBrowserClick(mouseX, mouseY);
                if (selectedBrowserItem != null) handleGridClick(mouseX, mouseY);
            }
            if (button == 1) handleGridRightClick(mouseX, mouseY);
        }
        return handled;
    }

    private void handleBrowserClick(double mouseX, double mouseY) {
        int start = browserScrollOffset * BROWSER_COLS;
        int end   = Math.min(start + BROWSER_VIS, filteredItems.size());

        for (int i = start; i < end; i++) {
            int local = i - start;
            int cellX = browserOriginX + (local % BROWSER_COLS) * SLOT_SIZE;
            int cellY = browserOriginY + (local / BROWSER_COLS) * SLOT_SIZE;

            if (mouseX >= cellX && mouseX < cellX + SLOT_SIZE
             && mouseY >= cellY && mouseY < cellY + SLOT_SIZE) {
                Item clicked    = filteredItems.get(i);
                selectedBrowserItem = (clicked == selectedBrowserItem) ? null : clicked;
                return;
            }
        }
    }

    private void handleGridClick(double mouseX, double mouseY) {
        for (int i = 0; i < 9; i++) {
            int slotX = gridOriginX + (i % 3) * SLOT_SIZE;
            int slotY = gridOriginY + (i / 3) * SLOT_SIZE;

            if (mouseX >= slotX && mouseX < slotX + SLOT_SIZE
             && mouseY >= slotY && mouseY < slotY + SLOT_SIZE) {
                craftingGrid[i] = new ItemStack(selectedBrowserItem);
                return;
            }
        }
    }

    private void handleGridRightClick(double mouseX, double mouseY) {
        for (int i = 0; i < 9; i++) {
            int slotX = gridOriginX + (i % 3) * SLOT_SIZE;
            int slotY = gridOriginY + (i / 3) * SLOT_SIZE;

            if (mouseX >= slotX && mouseX < slotX + SLOT_SIZE
             && mouseY >= slotY && mouseY < slotY + SLOT_SIZE) {
                craftingGrid[i] = null;
                return;
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY,
                                  double horizontalAmount, double verticalAmount) {
        // 1.21.1: mouseScrolled now has 4 params (added horizontalAmount)
        if (makeCraftableCheckbox.isChecked()) {
            int panelW = BROWSER_COLS * SLOT_SIZE + 8;
            int panelH = BROWSER_ROWS * SLOT_SIZE + 8;
            boolean over = mouseX >= browserOriginX - 2 && mouseX <= browserOriginX + panelW
                        && mouseY >= browserOriginY - 2 && mouseY <= browserOriginY + panelH;
            if (over) {
                int maxOff = Math.max(0,
                    (int) Math.ceil((double) filteredItems.size() / BROWSER_COLS) - BROWSER_ROWS);
                browserScrollOffset = (int) Math.max(0,
                    Math.min(maxOff, browserScrollOffset - verticalAmount));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    // ── Search ────────────────────────────────────────────────────────────────

    private void onSearchChanged(String query) {
        browserScrollOffset = 0;
        if (query == null || query.isBlank()) {
            filteredItems = new ArrayList<>(allItems);
            return;
        }
        String lower = query.toLowerCase();
        filteredItems = allItems.stream()
            .filter(item -> item.getName().getString().toLowerCase().contains(lower))
            .collect(Collectors.toList());
    }

    // ── Button actions ────────────────────────────────────────────────────────

    private void onAddModelClicked() {
        CompletableFuture.supplyAsync(ModFileManager::openJsonFileChooser)
            .thenAcceptAsync(path -> {
                if (path != null) {
                    selectedModelPath = path;
                    selectedFileLabel = java.nio.file.Path.of(path)
                        .getFileName().toString();
                } else {
                    selectedFileLabel = "No file selected.";
                }
            }, runnable -> MinecraftClient.getInstance().execute(runnable));
    }

    private void onSaveClicked() {
        if (selectedModelPath == null) {
            CustomModelMod.LOGGER.warn("[CustomModelScreen] Save clicked with no model selected.");
            return;
        }

        String[] ingredientIds = null;
        if (makeCraftableCheckbox.isChecked()) {
            ingredientIds = new String[9];
            for (int i = 0; i < 9; i++) {
                if (craftingGrid[i] != null && !craftingGrid[i].isEmpty()) {
                    // 1.21.1: Registries.ITEM.getId() unchanged
                    Identifier id = Registries.ITEM.getId(craftingGrid[i].getItem());
                    ingredientIds[i] = id.toString();
                } else {
                    ingredientIds[i] = "";
                }
            }
        }

        RuntimeModelLoader.registerModelAndReload(selectedModelPath, ingredientIds);
        this.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
