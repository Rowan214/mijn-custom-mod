package com.custommodelmod.io;

import com.custommodelmod.CustomModelMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Central file I/O utility for Custom Model Mod (1.21.1).
 *
 * Handles:
 *   - Config directory creation
 *   - Cross-platform native file chooser via LWJGL TinyFileDialogs
 *   - Copying uploaded Blockbench models into the mod's config folder
 *   - Generating Minecraft-format shaped crafting recipe JSONs
 *
 * Directory layout created in .minecraft/config/custommodelmod/:
 *   models/    <- uploaded Blockbench JSON files
 *   recipes/   <- generated Minecraft recipe JSON files
 */
public class ModFileManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Root: .minecraft/config/custommodelmod/ */
    public static final Path CONFIG_ROOT = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("custommodelmod");

    public static final Path MODELS_DIR  = CONFIG_ROOT.resolve("models");
    public static final Path RECIPES_DIR = CONFIG_ROOT.resolve("recipes");

    /** Creates the mod's directory structure (idempotent). */
    public static void ensureDirectoriesExist() throws IOException {
        Files.createDirectories(MODELS_DIR);
        Files.createDirectories(RECIPES_DIR);
        CustomModelMod.LOGGER.info("[ModFileManager] Directories ready: {}", CONFIG_ROOT);
    }

    /**
     * Opens a cross-platform native file-chooser dialog filtered to .json files.
     *
     * IMPORTANT: Blocks the calling thread. Always invoke from a background thread
     * and marshal the result back to the MC main thread via client.execute().
     *
     * @return absolute path of the chosen file, or null if the user cancelled
     */
    public static String openJsonFileChooser() {
        String result = TinyFileDialogs.tinyfd_openFileDialog(
            "Select a Blockbench Model (.json)",
            "",
            new CharSequence[]{"*.json"},
            "Blockbench Model Files (*.json)",
            false
        );
        if (result == null) {
            CustomModelMod.LOGGER.info("[ModFileManager] File chooser cancelled.");
        } else {
            CustomModelMod.LOGGER.info("[ModFileManager] Selected: {}", result);
        }
        return result;
    }

    /**
     * Copies the chosen Blockbench .json into the mod's models folder.
     * Overwrites silently if a file with the same name already exists.
     *
     * @param sourcePath absolute path string from openJsonFileChooser()
     * @return Path of the copied file inside MODELS_DIR
     */
    public static Path copyModelToModFolder(String sourcePath) throws IOException {
        if (sourcePath == null || sourcePath.isBlank()) {
            throw new IllegalArgumentException("sourcePath must not be null or blank.");
        }
        Path source      = Path.of(sourcePath);
        Path destination = MODELS_DIR.resolve(source.getFileName().toString());
        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
        CustomModelMod.LOGGER.info("[ModFileManager] Model copied to: {}", destination);
        return destination;
    }

    /**
     * Generates a Minecraft-format shaped crafting recipe JSON and writes it to
     * RECIPES_DIR.
     *
     * ingredientGrid layout (9-element, reading order):
     *   [0][1][2]
     *   [3][4][5]
     *   [6][7][8]
     * Use null or blank strings for empty slots.
     *
     * @param recipeId       output filename without extension (e.g. "my_sword")
     * @param ingredientGrid 9-element array of namespaced item IDs
     * @param resultItemId   namespaced result item (e.g. "custommodelmod:custom_item_1")
     * @return Path of the written recipe file
     */
    public static Path generateRecipeJson(String recipeId,
                                           String[] ingredientGrid,
                                           String resultItemId) throws IOException {
        if (ingredientGrid.length != 9) {
            throw new IllegalArgumentException(
                "ingredientGrid must have exactly 9 elements, got: " + ingredientGrid.length);
        }

        char[] alphabet    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        int letterIndex    = 0;
        Map<String, Character> itemToLetter = new LinkedHashMap<>();
        char[] patternChars = new char[9];

        for (int i = 0; i < 9; i++) {
            String itemId = ingredientGrid[i];
            boolean empty = (itemId == null || itemId.isBlank());
            if (empty) {
                patternChars[i] = ' ';
            } else {
                if (!itemToLetter.containsKey(itemId)) {
                    itemToLetter.put(itemId, alphabet[letterIndex++]);
                }
                patternChars[i] = itemToLetter.get(itemId);
            }
        }

        String row1 = new String(patternChars, 0, 3);
        String row2 = new String(patternChars, 3, 3);
        String row3 = new String(patternChars, 6, 3);

        JsonObject recipe = new JsonObject();
        recipe.addProperty("type", "minecraft:crafting_shaped");

        com.google.gson.JsonArray patternArray = new com.google.gson.JsonArray();
        patternArray.add(row1);
        patternArray.add(row2);
        patternArray.add(row3);
        recipe.add("pattern", patternArray);

        JsonObject keyObject = new JsonObject();
        for (Map.Entry<String, Character> e : itemToLetter.entrySet()) {
            JsonObject ingredient = new JsonObject();
            ingredient.addProperty("item", e.getKey());
            keyObject.add(String.valueOf(e.getValue()), ingredient);
        }
        recipe.add("key", keyObject);

        JsonObject result = new JsonObject();
        result.addProperty("item", resultItemId);
        result.addProperty("count", 1);
        recipe.add("result", result);

        Path outputPath = RECIPES_DIR.resolve(recipeId + ".json");
        Files.writeString(outputPath, GSON.toJson(recipe), StandardCharsets.UTF_8);
        CustomModelMod.LOGGER.info("[ModFileManager] Recipe written to: {}", outputPath);
        return outputPath;
    }
}
