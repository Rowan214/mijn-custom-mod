package com.custommodelmod.registry;

import com.custommodelmod.CustomModelMod;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Manages a pre-registered pool of 50 placeholder items
 * (custommodelmod:custom_item_1 … custom_item_50).
 *
 * NOTE for 1.21.1: FabricItemSettings was removed from Fabric API.
 * Use vanilla Item.Settings() directly — it now includes all the same
 * options (maxCount, rarity, food, etc.) without needing a Fabric wrapper.
 */
public class PlaceholderItemRegistry {

    public static final int POOL_SIZE    = 50;
    private static final String ITEM_PREFIX = "custom_item_";

    private static final List<Item>    ITEMS  = new ArrayList<>(POOL_SIZE);
    private static final boolean[]     IN_USE = new boolean[POOL_SIZE];

    /**
     * Registers all 50 placeholder items. Must be called from onInitialize()
     * before the registry freezes.
     */
    public static void registerAll() {
        for (int i = 1; i <= POOL_SIZE; i++) {
            // 1.21.1: use vanilla Item.Settings() — FabricItemSettings no longer exists
            Item item = new Item(new Item.Settings().maxCount(1));
            Identifier id = Identifier.of(CustomModelMod.MOD_ID, ITEM_PREFIX + i);
            Registry.register(Registries.ITEM, id, item);
            ITEMS.add(item);
        }
    }

    /**
     * Claims the next available (unassigned) pool slot in order.
     * Returns empty if all 50 slots are occupied.
     */
    public static Optional<Integer> claimNextSlot() {
        for (int i = 0; i < POOL_SIZE; i++) {
            if (!IN_USE[i]) {
                IN_USE[i] = true;
                CustomModelMod.LOGGER.info("[PlaceholderItemRegistry] Claimed slot {} ({}{}).",
                    i, ITEM_PREFIX, i + 1);
                return Optional.of(i);
            }
        }
        CustomModelMod.LOGGER.warn("[PlaceholderItemRegistry] All {} slots are in use!", POOL_SIZE);
        return Optional.empty();
    }

    /**
     * Forces a specific slot into IN_USE. Used by StartupStateLoader to
     * re-claim the exact slot originally assigned to a saved model.
     *
     * @return true if newly claimed; false if already in use (duplicate)
     */
    public static boolean forceClaimSlot(int slotIndex) {
        if (slotIndex < 0 || slotIndex >= POOL_SIZE) {
            throw new IllegalArgumentException("Slot index out of range: " + slotIndex);
        }
        if (IN_USE[slotIndex]) return false;
        IN_USE[slotIndex] = true;
        CustomModelMod.LOGGER.info("[PlaceholderItemRegistry] Force-claimed slot {} ({}{}).",
            slotIndex, ITEM_PREFIX, slotIndex + 1);
        return true;
    }

    /** Releases a slot so it can be reused by a future uploaded model. */
    public static void releaseSlot(int slotIndex) {
        if (slotIndex < 0 || slotIndex >= POOL_SIZE) {
            throw new IllegalArgumentException("Slot index out of range: " + slotIndex);
        }
        IN_USE[slotIndex] = false;
        CustomModelMod.LOGGER.info("[PlaceholderItemRegistry] Released slot {}.", slotIndex);
    }

    /** Returns the Item at the given zero-based pool index. */
    public static Item getItem(int slotIndex) {
        return ITEMS.get(slotIndex);
    }

    /** Returns an unmodifiable view of all registered placeholder items. */
    public static List<Item> getAllItems() {
        return Collections.unmodifiableList(ITEMS);
    }
}
