@echo off
REM ─────────────────────────────────────────────────────────────────────────────
REM GET_GRADLE_WRAPPER.bat
REM
REM Downloads gradle-wrapper.jar into gradle\wrapper\ so that gradlew.bat works
REM without needing a system Gradle installation.
REM
REM Run this once after extracting the source archive:
REM   GET_GRADLE_WRAPPER.bat
REM
REM Then build the mod with:
REM   gradlew.bat build
REM ─────────────────────────────────────────────────────────────────────────────

set WRAPPER_DIR=%~dp0gradle\wrapper
set JAR_PATH=%WRAPPER_DIR%\gradle-wrapper.jar
set GRADLE_VERSION=8.8
set JAR_URL=https://raw.githubusercontent.com/gradle/gradle/v%GRADLE_VERSION%.0/gradle/wrapper/gradle-wrapper.jar

if not exist "%WRAPPER_DIR%" mkdir "%WRAPPER_DIR%"

if exist "%JAR_PATH%" (
    echo gradle-wrapper.jar already present — skipping download.
    goto :done
)

echo Downloading gradle-wrapper.jar for Gradle %GRADLE_VERSION%...

powershell -Command "Invoke-WebRequest -Uri '%JAR_URL%' -OutFile '%JAR_PATH%'"

if exist "%JAR_PATH%" (
    echo Done! gradle-wrapper.jar saved.
    echo.
    echo You can now build the mod with:
    echo   gradlew.bat build
) else (
    echo ERROR: Download failed. Please check your internet connection.
    exit /b 1
)

:done
