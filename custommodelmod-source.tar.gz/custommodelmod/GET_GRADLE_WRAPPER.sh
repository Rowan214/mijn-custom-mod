#!/bin/sh
# ─────────────────────────────────────────────────────────────────────────────
# GET_GRADLE_WRAPPER.sh
#
# Downloads gradle-wrapper.jar into gradle/wrapper/ so that ./gradlew works
# without needing a system Gradle installation.
#
# Run this once after extracting the source archive:
#   chmod +x GET_GRADLE_WRAPPER.sh
#   ./GET_GRADLE_WRAPPER.sh
#
# Then build the mod with:
#   ./gradlew build
# ─────────────────────────────────────────────────────────────────────────────

set -e

WRAPPER_DIR="$(dirname "$0")/gradle/wrapper"
JAR_PATH="$WRAPPER_DIR/gradle-wrapper.jar"
GRADLE_VERSION="8.8"

# URL of the official gradle-wrapper.jar for Gradle 8.8
JAR_URL="https://raw.githubusercontent.com/gradle/gradle/v${GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar"

mkdir -p "$WRAPPER_DIR"

if [ -f "$JAR_PATH" ]; then
  echo "gradle-wrapper.jar already present — skipping download."
  exit 0
fi

echo "Downloading gradle-wrapper.jar for Gradle $GRADLE_VERSION..."

if command -v curl >/dev/null 2>&1; then
  curl -fsSL -o "$JAR_PATH" "$JAR_URL"
elif command -v wget >/dev/null 2>&1; then
  wget -q -O "$JAR_PATH" "$JAR_URL"
else
  echo "ERROR: neither curl nor wget found. Please install one and re-run this script."
  exit 1
fi

echo "Done! gradle-wrapper.jar saved to: $JAR_PATH"
echo ""
echo "You can now build the mod with:"
echo "  chmod +x gradlew"
echo "  ./gradlew build"
